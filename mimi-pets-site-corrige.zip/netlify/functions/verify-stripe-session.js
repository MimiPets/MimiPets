// Vérifie, côté serveur, qu'une session de paiement Stripe a réellement
// abouti à un paiement — avant que merci.html n'affiche "Commande confirmée".
//
// Pourquoi : un Payment Link Stripe redirige le client vers une URL de
// succès que TU choisis dans ton dashboard Stripe. Si cette URL est
// simplement "merci.html", n'importe qui pourrait aussi taper cette adresse
// directement sans avoir payé. La bonne pratique Stripe consiste à
// configurer l'URL de succès avec un identifiant de session :
//   https://ton-site.netlify.app/merci.html?session_id={CHECKOUT_SESSION_ID}
// (Stripe remplace automatiquement {CHECKOUT_SESSION_ID} par le vrai
// identifiant.) Cette fonction interroge ensuite Stripe avec cet identifiant
// pour confirmer que le paiement est réellement "paid" — le navigateur ne
// peut pas fabriquer un session_id valide correspondant à un vrai paiement.
//
// Variable d'environnement requise (Netlify > Site settings > Environment
// variables) :
//   STRIPE_SECRET_KEY   (commence par sk_live_... — jamais dans le code du site)

exports.handler = async function (event) {
  const sessionId = event.queryStringParameters?.session_id;

  if (!sessionId) {
    return { statusCode: 400, body: JSON.stringify({ verified: false, error: "session_id manquant." }) };
  }

  try {
    const res = await fetch(`https://api.stripe.com/v1/checkout/sessions/${encodeURIComponent(sessionId)}?expand[]=line_items`, {
      headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}` },
    });
    const session = await res.json();

    return {
      statusCode: 200,
      body: JSON.stringify({
        verified: session.payment_status === "paid",
        status: session.payment_status,
        amount: session.amount_total != null ? (session.amount_total / 100).toFixed(2) : null,
        currency: session.currency,
        email: session.customer_details?.email ?? null,
        orderId: session.metadata?.order_id ?? null,
        customerName: session.metadata?.customer_name ?? null,
        address: session.metadata?.address ?? null,
        lineItems: (session.line_items?.data || []).map(item => ({ name: item.description || item.price?.product?.name || 'Produit Mimi Pets', quantity: item.quantity || 1 })),
      }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ verified: false, error: "Vérification impossible." }) };
  }
};
