// Netlify function: creates a Stripe Checkout Session from the validated product catalog.
// Required environment variable: STRIPE_SECRET_KEY (sk_live_... or sk_test_...)
const PRODUCTS = {
  'mimi-ball': { name: 'Mimi Pets — Balle interactive pour chat', unit_amount: 999, colors: ['Bleu','Jaune','Rouge','Vert'] },
  'cat-fountain': { name: 'Petite fontaine à eau silencieuse', unit_amount: 1899, colors: [] },
  'cat-scratcher': { name: 'Brosse de massage à gratter', unit_amount: 599, colors: [] },
  'cat-harness': { name: 'Harnais et laisse abeille', unit_amount: 749, colors: [] },
  'cat-vest': { name: 'Petit gilet de promenade', unit_amount: 949, colors: [] },
  'cozy-nest': { name: 'Petit nid douillet abeille', unit_amount: 2999, colors: [] },
  'cat-bird': { name: 'Petit oiseau interactif pour chat', unit_amount: 545, colors: [] },
  'dog-bounce-ball': { name: 'Balle rebondissante pour chien', unit_amount: 699, colors: [] },
  'dog-plush': { name: 'Petit compagnon en peluche', unit_amount: 699, colors: [] },
  'grooming-gloves': { name: 'Paire de gants de toilettage', unit_amount: 649, colors: ['Bleu','Noir','Rose','Vert'] },
  'custom-cushion': { name: 'Coussin personnalisé Mimi Pets', unit_amount: 799, colors: [] }
};

function json(statusCode, body){ return { statusCode, headers:{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'}, body:JSON.stringify(body) }; }

exports.handler = async function(event){
  if(event.httpMethod !== 'POST') return json(405,{error:'Méthode non autorisée.'});
  if(!process.env.STRIPE_SECRET_KEY) return json(500,{error:'STRIPE_SECRET_KEY n’est pas configurée sur Netlify.'});
  let data;
  try{ data=JSON.parse(event.body||'{}'); }catch(e){ return json(400,{error:'Données invalides.'}); }
  if(!data.email || !data.fname || !data.lname || !data.address || !data.city || !data.zip) return json(400,{error:'Informations client incomplètes.'});
  if(!Array.isArray(data.cart) || !data.cart.length) return json(400,{error:'Panier vide.'});

  const lineItems=[];
  const cushionSizes = {'10 cm':799,'20 cm':1299,'30 cm':1799,'40 cm':2299,'50 cm':2499};
  for(const item of data.cart){
    const p=PRODUCTS[item.id];
    const qty=Number.isInteger(item.qty)?item.qty:0;
    if(!p || qty<1 || qty>10) return json(400,{error:'Produit ou quantité invalide.'});
    if(p.colors.length && !p.colors.includes(item.color)) return json(400,{error:'Couleur invalide.'});
    const isCushion=item.id==='custom-cushion';
    if(isCushion && !cushionSizes[item.size]) return json(400,{error:'Taille de coussin invalide.'});
    const label=isCushion ? `${p.name} — ${item.size}` : (p.colors.length ? `${p.name} — ${item.color}` : p.name);
    const unitAmount=isCushion ? cushionSizes[item.size] : p.unit_amount;
    lineItems.push({
      price_data:{currency:'eur',product_data:{name:label},unit_amount:unitAmount},
      quantity:qty
    });
  }

  const siteUrl=(process.env.URL || 'https://mimi-pets.netlify.app').replace(/\/$/,'');
  const orderId='MP-'+Math.floor(100000+Math.random()*900000);
  const params=new URLSearchParams();
  params.set('mode','payment'); params.set('success_url',siteUrl+'/merci.html?session_id={CHECKOUT_SESSION_ID}'); params.set('cancel_url',siteUrl+'/checkout.html');
  params.set('customer_email',String(data.email).slice(0,200)); params.set('billing_address_collection','auto');
  params.set('phone_number_collection[enabled]','true');
  params.set('shipping_address_collection[allowed_countries][0]','FR');
  params.set('metadata[order_id]',orderId); params.set('metadata[customer_name]',`${data.fname} ${data.lname}`.slice(0,500)); params.set('metadata[phone]',String(data.phone||'').slice(0,500)); params.set('metadata[address]',`${data.address}, ${data.zip} ${data.city}`.slice(0,500));
  data.cart.forEach((item,i)=>{params.set(`line_items[${i}][price_data][currency]`,'eur');const p=PRODUCTS[item.id];const isCushion=item.id==='custom-cushion';const label=isCushion?`${p.name} — ${item.size}`:(p.colors.length?`${p.name} — ${item.color}`:p.name);const unitAmount=isCushion?cushionSizes[item.size]:p.unit_amount;params.set(`line_items[${i}][price_data][product_data][name]`,label);params.set(`line_items[${i}][price_data][unit_amount]`,String(unitAmount));params.set(`line_items[${i}][quantity]`,String(item.qty));});

  try{
    const r=await fetch('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{'Authorization':`Bearer ${process.env.STRIPE_SECRET_KEY}`,'Content-Type':'application/x-www-form-urlencoded'},body:params});
    const session=await r.json();
    if(!r.ok || !session.url) return json(502,{error:session.error?.message||'Stripe n’a pas pu créer la session.'});
    return json(200,{url:session.url,orderId});
  }catch(e){ return json(500,{error:'Erreur de connexion à Stripe.'}); }
};
