Ajoute ici les images des nouveaux produits.
Chaque produit possède son propre dossier.
Noms attendus quand une photo principale est disponible : main.png ou main.jpg.
Pour les produits à variantes couleur, tu peux ajouter les images dans le dossier du produit.
