Le coussin est personnalisé par le client au checkout : il importe la photo de son animal.
Les tailles et prix sont définis dans le catalogue.
