# Mimi Pets — Guide de mise en route

Ce dossier contient ton site complet. Voici tout ce qu'il contient, comment le tester, et comment le mettre en ligne pour de vrai.

## 1. Ce que contient le dossier

```
mimi-pets-site/
├── index.html                 → la boutique (page d'accueil)
├── checkout.html               → la page de paiement
├── merci.html                  → la page de confirmation de commande
├── accueil-chaleureux.html     → une version alternative de la page d'accueil (plus douce), optionnelle
├── images/
│   ├── main-product.png        → photo de couverture (hero)
│   ├── color-blue.png          → Mimi Pets bleu
│   ├── color-yellow.png        → Mimi Pets jaune
│   ├── color-red.png           → Mimi Pets rouge
│   ├── color-green.png         → Mimi Pets vert
│   └── products/
│       └── dog-interactive-ball/
│           └── PLACE-IMAGE-HERE.txt → déposer ici la photo du produit
└── netlify/
    └── functions/
        └── verify-stripe-session.js   → fonction serveur qui vérifie réellement un paiement Stripe
```

**Règle d'or : ne déplace jamais un fichier HTML sans déplacer le dossier `images/` et `netlify/` avec lui.** Ils doivent toujours rester au même niveau les uns que les autres, exactement comme dans le schéma ci-dessus.

## 2. Comment ça marche, dans l'ordre

1. Le client arrive sur **index.html**, choisit une couleur et une quantité, remplit ses infos.
2. En validant, il est envoyé vers **checkout.html**, qui récapitule sa commande et propose de payer par carte (Stripe).
3. Une fois payé, Stripe le renvoie sur **merci.html**, qui vérifie le paiement auprès de Stripe avant d'afficher la confirmation.

Les informations de commande transitent uniquement par le navigateur du client (aucune base de données chez toi) — voir la section 5 pour savoir où tu peux réellement voir tes commandes.

## 3. Tester le site sur ton ordinateur (avant de le mettre en ligne)

Double-clique simplement sur `index.html` — il s'ouvre dans ton navigateur. Tu peux tester tout le parcours (choix de couleur → commande → paiement) sans rien installer. Le bouton de paiement ne débitera rien tant qu'il n'est pas configuré (étape 4).

## 4. Mettre le site en ligne (avec HTTPS gratuit)

1. Crée un compte sur **netlify.com** (gratuit).
2. Glisse le dossier complet (tel quel, avec `images/` et `netlify/` dedans) sur leur page "Deploy".
3. En 30 secondes, ton site est en ligne avec une adresse du type `ton-site.netlify.app`, HTTPS activé automatiquement.

## 5. Activer les vrais paiements (Stripe)

Par défaut, le bouton de paiement affiche un message "pas encore configuré" — aucun risque de faire croire à un client qu'il a payé alors que ce n'est pas le cas. Pour l'activer, ouvre `checkout.html` et cherche la section `CONFIGURATION DU PAIEMENT` tout en haut du script.

1. Crée un compte sur **dashboard.stripe.com**.
2. Va dans Produits → Payment links, crée un lien au bon prix (9,99 €, ou ajuste selon le prix actuel du site).
3. Copie l'URL donnée et colle-la dans `STRIPE_PAYMENT_LINK` (dans `checkout.html`).
4. Stripe gère le paiement, l'encaissement, et te montre toutes tes commandes réelles dans son dashboard — c'est ta vraie source de vérité, pas Formspree (voir section 6).

### Voir tes commandes (Formspree, optionnel mais conseillé)
Sans ça, tu ne reçois aucune notification de commande ailleurs que dans ton dashboard Stripe.
1. Crée un compte gratuit sur **formspree.io**, crée un formulaire.
2. Copie l'URL donnée (type `https://formspree.io/f/xxxxxxx`) dans `FORMSPREE_ENDPOINT` (dans `checkout.html`).
3. Chaque fois qu'un client clique sur "Payer", ses infos partent vers Formspree — **attention, ça veut dire "quelqu'un a tenté de payer", pas "quelqu'un a payé"** (voir section 6).

## 6. Ce qui est déjà sécurisé (et ce qui reste une limite connue)

- ✅ Toutes les données saisies par le client sont protégées contre l'injection de code (XSS).
- ✅ Le prix est toujours recalculé côté site à partir d'une quantité validée (1, 2 ou 3).
- ✅ **La confirmation de commande est vérifiée côté serveur.** `merci.html` ne fait jamais confiance à ce que le navigateur lui raconte : elle réinterroge Stripe directement au chargement de la page (via `verify-stripe-session.js`), et n'affiche "Commande confirmée" que si le paiement est réellement confirmé par Stripe. Ça suppose que la vérification est bien configurée — voir section 7.
- ✅ Le formulaire valide vraiment le format de l'email, du téléphone, et la longueur des champs — plus seulement "rempli ou pas".
- ✅ Un champ piège invisible bloque les robots de spam basiques.
- ✅ Aucune clé secrète en dur dans le code — `STRIPE_SECRET_KEY` vit uniquement dans les variables d'environnement Netlify.
- ⚠️ **Formspree n'est pas une preuve de paiement.** Un email Formspree veut dire "quelqu'un a cliqué sur Payer", pas "quelqu'un a payé" — le client peut très bien avoir annulé sur la page Stripe après. Pour savoir qui a vraiment payé, regarde ton dashboard Stripe, c'est la seule source fiable.
- ⚠️ La fonction serveur `verify-stripe-session` reste publiquement appelable — aucun vrai rate limiting n'est garanti (voir les commentaires dans `netlify.toml` pour les vraies options si tu veux aller plus loin).

## 7. Activer la vérification serveur (obligatoire pour une vraie boutique)

En plus de `STRIPE_PAYMENT_LINK` déjà vu, `merci.html` a son propre bloc de configuration en haut de son script :

- `STRIPE_VERIFY_ENDPOINT` → URL de la fonction `verify-stripe-session`

Pour l'activer :
1. Sur **dashboard.stripe.com** → Développeurs → Clés API, copie la **clé secrète** (`sk_live_...`).
2. Dans Netlify → Site settings → Environment variables, ajoute `STRIPE_SECRET_KEY` avec cette clé comme valeur (jamais dans un fichier de code).
3. Redéploie le site pour que la fonction `verify-stripe-session` soit active.
4. Dans Netlify → onglet Functions, récupère son adresse (généralement `https://ton-site.netlify.app/.netlify/functions/verify-stripe-session`) et colle-la dans `STRIPE_VERIFY_ENDPOINT` (dans `merci.html`).
5. Sur ton Payment Link Stripe, configure l'URL de confirmation après paiement sur :
```
https://ton-site.netlify.app/merci.html?session_id={CHECKOUT_SESSION_ID}
```
Stripe remplace automatiquement `{CHECKOUT_SESSION_ID}` par le vrai identifiant — c'est ce qui permet à `merci.html` de vérifier le paiement.

Sans tout ça configuré, le site continue de fonctionner mais `merci.html` affichera "Vérification non configurée" plutôt que d'afficher une fausse confirmation.

## 8. Réglages rapides que tu changeras peut-être

| Ce que tu veux changer | Où |
|---|---|
| Prix unitaire (actuellement 9,99 €) | `UNIT_PRICE` dans `checkout.html` |
| Seuil de livraison offerte (actuellement 2 articles) | Bandeau tout en haut de `index.html` |
| Photo de couverture | Remplace `images/main-product.png` par un autre fichier du même nom |
| Texte, couleurs, sections de la page d'accueil | `index.html` |

## 9. Une limite à connaître (pas technique, commerciale)

L'image de couverture actuelle a été générée par IA et montre un produit avec LED et queue rigide, différent des vraies photos produit (balle en tissu, cordon souple) utilisées ailleurs sur le site. Un client qui commande en se basant sur cette image risque d'être surpris à la réception. À corriger avant de vraiment vendre, pour éviter tout souci de publicité trompeuse.


## Panier multi-produits
Le checkout utilise une Netlify Function `create-checkout-session.js`. Configure `STRIPE_SECRET_KEY` dans les variables d’environnement Netlify. Le catalogue et les prix sont vérifiés côté serveur avant la création de la session Stripe.

## Organisation de la boutique

La boutique comporte maintenant uniquement deux univers : **Chat** et **Chien**.
Quand le visiteur choisit **Chat** ou **Chien**, il voit directement les produits correspondant à cet animal. Les catégories intermédiaires et les anciennes catégories NAC, Oiseaux et Autres animaux ont été retirées.

Pour ajouter les images d'un nouveau produit, crée un dossier dans `images/products/nom-du-produit/` et place ses images dedans. Pour la Balle interactive pour chien, la photo principale doit être `images/products/dog-interactive-ball/main.png`.

Le choix de couleur de la Balle Mimi Pets utilise maintenant de vraies miniatures : cliquer sur une couleur change immédiatement la photo principale du produit.

## Catalogue issu du catalogue PDF

Le catalogue du site a été enrichi avec les produits et prix indiqués dans le catalogue fourni :
- Chat : jouet yo-yo 9,99 €, fontaine 18,99 €, brosse 5,99 €, harnais abeille 7,49 €, gilet 9,49 €, nid 29,99 €, oiseau interactif 5,45 €.
- Chien : balle rebondissante 6,99 €, peluche 6,99 €, gants 6,49 €, gilet 9,49 €, nid 29,99 €.
- Partagé chat/chien : gants et coussin personnalisé.
- Coussin : 10 cm 7,99 €, 20 cm 12,99 €, 30 cm 17,99 €, 40 cm 22,99 €, 50 cm 24,99 €.
- Une photo est demandée au checkout lorsqu'un coussin personnalisé est présent dans le panier. Le formulaire Netlify `mimi-personnalisation` reçoit la photo et les informations de commande.
